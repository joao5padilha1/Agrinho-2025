let caminhaoX = -100;
let pessoas = [];
let fogos = [];

function setup() {
  createCanvas(800, 400);
  rectMode(CENTER);
  noStroke();

  // Criar pessoas do campo (lado esquerdo) e da cidade (lado direito)
  for (let i = 0; i < 10; i++) {
    pessoas.push(new Pessoa(random(100, 350), random(250, 380), color(34, 139, 34))); // verde do campo
    pessoas.push(new Pessoa(random(450, 700), random(250, 380), color(70, 130, 180))); // azul da cidade
  }
}

function draw() {
  background(135, 206, 235); // céu azul claro

  // Campo
  fill(144, 238, 144);
  rect(200, 300, 400, 200);

  // Cidade
  fill(169, 169, 169);
  rect(600, 300, 400, 200);

  // Estrada
  fill(50);
  rect(width / 2, height - 25, width, 50);

  // Caminhão
  drawCaminhao(caminhaoX, height - 65);
  caminhaoX += 2;
  if (caminhaoX > width + 100) {
    caminhaoX = -100;
  }

  // Pessoas dançando
  for (let p of pessoas) {
    p.dancar();
    p.mostrar();
  }

  // Fogos de artifício
  if (frameCount % 60 === 0) {
    fogos.push(new Fogo(random(width), random(height / 2)));
  }

  for (let i = fogos.length - 1; i >= 0; i--) {
    fogos[i].atualizar();
    fogos[i].mostrar();
    if (fogos[i].acabou()) {
      fogos.splice(i, 1);
    }
  }

  // Texto
  fill(255);
  textSize(26);
  textAlign(CENTER);
  text("Festejando a Conexão Campo e Cidade!", width / 2, 40);
}

// Desenha caminhão simplificado
function drawCaminhao(x, y) {
  fill(255, 0, 0);
  rect(x, y, 80, 30); // carroceria
  fill(0, 0, 255);
  rect(x + 40, y - 15, 30, 30); // cabine
  fill(0);
  ellipse(x - 25, y + 15, 20);
  ellipse(x + 25, y + 15, 20);
}

// Pessoa
class Pessoa {
  constructor(x, y, c) {
    this.x = x;
    this.y = y;
    this.cor = c;
    this.offset = random(TWO_PI);
  }

  dancar() {
    this.dy = sin(frameCount * 0.1 + this.offset) * 2;
  }

  mostrar() {
    fill(this.cor);
    ellipse(this.x, this.y + this.dy, 10); // cabeça
    rect(this.x, this.y + 15 + this.dy, 3, 15); // corpo
    line(this.x, this.y + 20 + this.dy, this.x - 5, this.y + 25 + this.dy); // braços
    line(this.x, this.y + 20 + this.dy, this.x + 5, this.y + 25 + this.dy);
    line(this.x, this.y + 30 + this.dy, this.x - 3, this.y + 35 + this.dy); // pernas
    line(this.x, this.y + 30 + this.dy, this.x + 3, this.y + 35 + this.dy);
  }
}

// Fogo de artifício
class Fogo {
  constructor(x, y) {
    this.pos = createVector(x, y);
    this.particles = [];
    for (let i = 0; i < 50; i++) {
      this.particles.push(new Particula(x, y));
    }
  }

  atualizar() {
    for (let p of this.particles) {
      p.atualizar();
    }
  }

  mostrar() {
    for (let p of this.particles) {
      p.mostrar();
    }
  }

  acabou() {
    return this.particles.every(p => p.vida <= 0);
  }
}

class Particula {
  constructor(x, y) {
    this.pos = createVector(x, y);
    this.vel = p5.Vector.random2D().mult(random(1, 4));
    this.vida = 255;
    this.cor = color(random(255), random(255), random(255));
  }

  atualizar() {
    this.pos.add(this.vel);
    this.vel.mult(0.95);
    this.vida -= 4;
  }

  mostrar() {
    noStroke();
    fill(this.cor.levels[0], this.cor.levels[1], this.cor.levels[2], this.vida);
    ellipse(this.pos.x, this.pos.y, 4);
  }
}
